#!/usr/bin/env python3
"""Exact finite checks for the even-wheel construction.

For each requested even rank n, this script:
  * builds the wheel with n rim vertices;
  * checks that X,Y,Z,W are spanning trees;
  * recomputes all four exchange tables from the graphic matroid;
  * enumerates every possible common omission multiset of size n-1 and
    verifies that none admits compatible Y/Z boundary matchings and a corner.

The paper contains a symbolic proof for every even n.  This program is only an
independent check of finite instances.
"""
from __future__ import annotations

from functools import lru_cache
from itertools import combinations
from typing import Iterable


def bit_elements(mask: int) -> list[int]:
    return [i for i in range(mask.bit_length()) if (mask >> i) & 1]


def wheel_edges(n: int) -> list[tuple[int, int]]:
    hub = n
    return [(hub, i) for i in range(n)] + [(i, (i + 1) % n) for i in range(n)]


def is_tree(n: int, edges: list[tuple[int, int]], mask: int) -> bool:
    if mask.bit_count() != n:
        return False
    parent = list(range(n + 1))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for k, (u, v) in enumerate(edges):
        if not ((mask >> k) & 1):
            continue
        u, v = find(u), find(v)
        if u == v:
            return False
        parent[u] = v
    return True


def compositions(total: int, parts: int) -> Iterable[tuple[int, ...]]:
    def rec(pos: int, left: int, prefix: list[int]) -> Iterable[tuple[int, ...]]:
        if pos == parts - 1:
            yield tuple(prefix + [left])
            return
        for value in range(left + 1):
            yield from rec(pos + 1, left - value, prefix + [value])

    yield from rec(0, total, [])


def has_matching(copies: list[int], targets: list[int], exchange: list[list[bool]]) -> bool:
    copies = sorted(copies, key=lambda x: sum(exchange[x][y] for y in targets))

    @lru_cache(maxsize=None)
    def dfs(k: int, used: int) -> bool:
        if k == len(copies):
            return True
        x = copies[k]
        for y in targets:
            if not ((used >> y) & 1) and exchange[x][y]:
                if dfs(k + 1, used | (1 << y)):
                    return True
        return False

    return dfs(0, 0)


def check_rank(n: int) -> None:
    if n < 4 or n % 2:
        raise ValueError("n must be even and at least 4")
    m = n // 2
    edges = wheel_edges(n)

    # Edge numbers 0..n-1 are spokes s_j; n..2n-1 are rim edges r_j.
    A = {n + (2 * i + 1) % n for i in range(m)}
    B = {2 * i for i in range(m)}
    C = {2 * i + 1 for i in range(m)}
    D = {n + 2 * i for i in range(m)}
    bases = [A | B, A | C, B | D, C | D]
    X, Y, Z, W = [sum(1 << e for e in base) for base in bases]
    assert all(is_tree(n, edges, base) for base in (X, Y, Z, W))

    xe, ye, ze, we = map(bit_elements, (X, Y, Z, W))
    exch_y = [[is_tree(n, edges, (X & ~(1 << x)) | (1 << y)) for y in ye] for x in xe]
    exch_z = [[is_tree(n, edges, (X & ~(1 << x)) | (1 << z)) for z in ze] for x in xe]

    # Recompute and check the symbolic tables.  xe is sorted B then A in this encoding,
    # so compare as sets of edge numbers rather than positions.
    actual_y = {x: {ye[j] for j, ok in enumerate(row) if ok} for x, row in zip(xe, exch_y)}
    actual_z = {x: {ze[j] for j, ok in enumerate(row) if ok} for x, row in zip(xe, exch_z)}
    for i in range(m):
        a, b, c, d = n + (2 * i + 1) % n, 2 * i, 2 * i + 1, n + 2 * i
        c_prev = 2 * ((i - 1) % m) + 1
        d_prev = n + 2 * ((i - 1) % m)
        assert actual_y[a] == {a, c}
        assert actual_z[a] == {d}
        assert actual_y[b] == {c_prev}
        assert actual_z[b] == {b, d_prev, d}

    # Exhaust the boundary criterion from the common-omission lemma.
    multiset_count = 0
    for counts in compositions(n - 1, n):
        multiset_count += 1
        copies = [i for i, count in enumerate(counts) for _ in range(count)]
        possible_y_missing: list[int] = []
        possible_z_missing: list[int] = []
        for miss in range(n):
            targets = [j for j in range(n) if j != miss]
            if has_matching(copies, targets, exch_y):
                possible_y_missing.append(miss)
            if has_matching(copies, targets, exch_z):
                possible_z_missing.append(miss)
        for ym in possible_y_missing:
            y0 = Y & ~(1 << ye[ym])
            for zm in possible_z_missing:
                z0 = Z & ~(1 << ze[zm])
                for w in we:
                    if is_tree(n, edges, y0 | (1 << w)) and is_tree(n, edges, z0 | (1 << w)):
                        raise AssertionError(
                            f"boundary witness found in rank {n}: counts={counts}, "
                            f"Y-missing={ye[ym]}, Z-missing={ze[zm]}, corner={w}"
                        )
    print(f"rank {n}: verified; omission multisets checked={multiset_count}")


if __name__ == "__main__":
    for rank in (4, 6, 8, 10):
        check_rank(rank)
