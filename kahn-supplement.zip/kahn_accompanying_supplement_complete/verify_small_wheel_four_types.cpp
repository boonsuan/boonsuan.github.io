#include <bits/stdc++.h>
using namespace std;
using U64 = uint64_t;

struct Graph {
    int V, E, rank;
    vector<pair<int,int>> ends;
};

bool is_tree(const Graph& g, U64 mask) {
    if (__builtin_popcountll(mask) != g.rank) return false;
    vector<int> p(g.V), sz(g.V,1);
    iota(p.begin(), p.end(), 0);
    function<int(int)> find = [&](int x){ return p[x]==x?x:p[x]=find(p[x]); };
    for (int e=0;e<g.E;e++) if ((mask>>e)&1ULL) {
        auto [a,b]=g.ends[e];
        a=find(a); b=find(b);
        if (a==b) return false;
        if (sz[a]<sz[b]) swap(a,b);
        p[b]=a; sz[a]+=sz[b];
    }
    int r=find(0);
    for (int v=1;v<g.V;v++) if (find(v)!=r) return false;
    return true;
}

vector<U64> enumerate_trees(const Graph& g) {
    vector<U64> out;
    U64 lim=1ULL<<g.E;
    for (U64 m=0;m<lim;m++) if (__builtin_popcountll(m)==g.rank && is_tree(g,m)) out.push_back(m);
    return out;
}

vector<vector<int>> omission_multisets(int n) {
    vector<vector<int>> out;
    vector<int> cur(n-1);
    function<void(int,int)> rec=[&](int pos,int lo){
        if(pos==n-1){out.push_back(cur);return;}
        for(int x=lo;x<n;x++){cur[pos]=x;rec(pos+1,x);}
    };
    rec(0,0);
    return out;
}

// Return a global-edge mask of y0 in Y for which occurrences om can be matched
// bijectively to Y\{y0} using the exchange relation allow[pos][y-index].
U64 possible_omitted(const vector<int>& om, const vector<int>& Xedges,
                     const vector<int>& Yedges, const array<U64, 16>& exch) {
    int n=Xedges.size();
    U64 ans=0;
    for(int omit=0;omit<n;omit++){
        vector<int> rights;
        for(int j=0;j<n;j++) if(j!=omit) rights.push_back(j);
        vector<int> occ=om;
        sort(occ.begin(),occ.end(),[&](int a,int b){
            int ca=0,cb=0;
            for(int j:rights){ca += (exch[a]>>j)&1ULL; cb += (exch[b]>>j)&1ULL;}
            return ca<cb;
        });
        bool ok=false;
        function<void(int,U64)> rec=[&](int k,U64 used){
            if(ok) return;
            if(k==(int)occ.size()){ok=true;return;}
            U64 avail=exch[occ[k]];
            avail &= ~used;
            avail &= ~(1ULL<<omit);
            while(avail){int j=__builtin_ctzll(avail);avail&=avail-1;rec(k+1,used|(1ULL<<j));}
        };
        rec(0,0);
        if(ok) ans |= 1ULL<<Yedges[omit];
    }
    return ans;
}

vector<int> bits(U64 m){vector<int> v; while(m){int e=__builtin_ctzll(m);m&=m-1;v.push_back(e);}return v;}

string maskstr(U64 m, int N){
    vector<string> a;
    for(int e=0;e<2*N;e++) if((m>>e)&1ULL){
        if(e<N) a.push_back("s"+to_string(e)); else a.push_back("r"+to_string(e-N));
    }
    string s="{"; for(size_t i=0;i<a.size();i++){if(i)s+=",";s+=a[i];} return s+"}";
}

int main(int argc,char**argv){
    int N=5;
    if(argc>1) N=atoi(argv[1]);
    Graph g; g.V=N+1; g.rank=N; g.E=2*N;
    for(int i=0;i<N;i++) g.ends.push_back({N,i});
    for(int i=0;i<N;i++) g.ends.push_back({i,(i+1)%N});
    auto trees=enumerate_trees(g);
    int T=trees.size();
    cerr<<"N="<<N<<" trees="<<T<<"\n";
    unordered_map<U64,int> tid;
    for(int i=0;i<T;i++) tid[trees[i]]=i;

    // Dihedral action edge permutations and tree orbit representatives.
    vector<vector<int>> perms;
    for(int refl=0;refl<2;refl++) for(int sh=0;sh<N;sh++){
        vector<int> p(2*N);
        auto f=[&](int v){
            int w = refl ? ((sh-v)%N+N)%N : (v+sh)%N;
            return w;
        };
        for(int i=0;i<N;i++) p[i]=f(i); // spoke
        for(int i=0;i<N;i++){
            int a=f(i), b=f((i+1)%N);
            int r=-1;
            for(int j=0;j<N;j++){
                int x=j,y=(j+1)%N;
                if((x==a&&y==b)||(x==b&&y==a)){r=j;break;}
            }
            if(r<0){cerr<<"perm error\n";return 2;}
            p[N+i]=N+r;
        }
        perms.push_back(p);
    }
    auto act=[&](U64 m,const vector<int>&p){U64 z=0;for(int e=0;e<2*N;e++)if((m>>e)&1ULL)z|=1ULL<<p[e];return z;};
    vector<int> reps;
    vector<char> seen(T,false);
    for(int i=0;i<T;i++) if(!seen[i]){
        reps.push_back(i);
        for(auto&p:perms){auto it=tid.find(act(trees[i],p)); if(it!=tid.end()) seen[it->second]=true;}
    }
    cerr<<"tree_orbits="<<reps.size()<<"\n";
    auto oms=omission_multisets(N);
    int O=oms.size();
    cerr<<"omission_multisets="<<O<<"\n";

    long long quads=0;
    auto start=chrono::steady_clock::now();
    for(int rr=0;rr<(int)reps.size();rr++){
        int xi=reps[rr]; U64 X=trees[xi]; auto xe=bits(X);
        // omitMasks[y][o] = global-edge mask of possible omitted elements of Y.
        vector<vector<U64>> omitMasks(T, vector<U64>(O));
        for(int yi=0;yi<T;yi++){
            U64 Y=trees[yi]; auto ye=bits(Y);
            array<U64,16> exch{}; // indexed by position in X; bits by position in Y
            for(int a=0;a<N;a++) for(int b=0;b<N;b++){
                U64 S=(X & ~(1ULL<<xe[a])) | (1ULL<<ye[b]);
                if(is_tree(g,S)) exch[a] |= 1ULL<<b;
            }
            for(int o=0;o<O;o++) omitMasks[yi][o]=possible_omitted(oms[o],xe,ye,exch);
        }
        // completion[y][w][global omitted edge e] = global W-edge mask; compute on fly cached.
        vector<vector<array<U64,16>>> comp(T, vector<array<U64,16>>(T));
        for(int yi=0;yi<T;yi++){
            U64 Y=trees[yi]; auto ye=bits(Y);
            for(int wi=0;wi<T;wi++){
                U64 W=trees[wi]; auto we=bits(W);
                for(int e:ye){
                    U64 cm=0;
                    for(int w:we){
                        U64 S=(Y & ~(1ULL<<e)) | (1ULL<<w);
                        if(is_tree(g,S)) cm|=1ULL<<w;
                    }
                    comp[yi][wi][e]=cm;
                }
            }
        }
        for(int yi=0;yi<T;yi++) for(int zi=yi;zi<T;zi++) for(int wi=0;wi<T;wi++){
            quads++;
            bool success=false;
            for(int o=0;o<O && !success;o++){
                U64 my=omitMasks[yi][o], mz=omitMasks[zi][o];
                if(!my||!mz) continue;
                U64 unionY=0;
                U64 t=my;
                while(t){int e=__builtin_ctzll(t);t&=t-1;unionY |= comp[yi][wi][e];}
                if(!unionY) continue;
                t=mz;
                while(t){int e=__builtin_ctzll(t);t&=t-1;if(unionY & comp[zi][wi][e]){success=true;break;}}
            }
            if(!success){
                static long long bad=0; static int mind=5; static array<U64,4> best{};
                bad++;
                array<U64,4> qv={X,trees[yi],trees[zi],trees[wi]};
                set<U64> ds(qv.begin(),qv.end());
                if((int)ds.size()<mind){mind=ds.size();best=qv; cerr<<"new min distinct="<<mind<<" bad="<<bad<<"\n";}
                if(mind<=3){
                  cout<<"FOUND <=3 DISTINCT BAD rank="<<N<<" bad="<<bad<<"\n";
                  cout<<"X="<<maskstr(best[0],N)<<"\nY="<<maskstr(best[1],N)<<"\nZ="<<maskstr(best[2],N)<<"\nW="<<maskstr(best[3],N)<<"\n";
                  return 0;
                }
            }
        }
        auto now=chrono::steady_clock::now();
        cerr<<"orbit "<<rr+1<<"/"<<reps.size()<<" quads="<<quads<<" elapsed_s="<<chrono::duration<double>(now-start).count()<<"\n";
    }
    cout<<"NO <=3-DISTINCT BAD BLOCK QUADRUPLE in wheel rank="<<N<<"; Xorbits="<<reps.size()<<" quads="<<quads<<"\n";
}
