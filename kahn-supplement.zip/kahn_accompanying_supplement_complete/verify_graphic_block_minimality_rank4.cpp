#include <bits/stdc++.h>
using namespace std;
struct Graph{
 int V,m; vector<pair<int,int>> e; vector<int> bases; vector<char> baseflag;
 bool isbase_slow(int mask) const {
  if(__builtin_popcount((unsigned)mask)!=4)return false;
  vector<int> p(V);iota(p.begin(),p.end(),0);
  function<int(int)> f=[&](int x){return p[x]==x?x:p[x]=f(p[x]);};
  for(int k=0;k<m;k++)if(mask>>k&1){int a=f(e[k].first),b=f(e[k].second);if(a==b)return false;p[a]=b;}
  // A forest of size 4 is a basis iff its component count equals V-4,
  // equivalently it spans each connected component of the ambient graph.
  // Compare partitions: every ambient edge must have endpoints connected by selected forest.
  for(auto [a,b]:e)if(f(a)!=f(b))return false;
  return true;
 }
 bool isbase(int mask)const{return mask<(int)baseflag.size()&&baseflag[mask];}
};

bool connected_mask(int V,const vector<pair<int,int>>& all,int em){
 vector<int>p(V);iota(p.begin(),p.end(),0);function<int(int)>f=[&](int x){return p[x]==x?x:p[x]=f(p[x]);};
 for(int k=0;k<(int)all.size();k++)if(em>>k&1){int a=f(all[k].first),b=f(all[k].second);p[a]=b;}
 int r=f(0);for(int i=1;i<V;i++)if(f(i)!=r)return false;return true;
}
vector<Graph> connected_graphs_rank(int r,int maxm){
 int V=r+1;vector<pair<int,int>>all;for(int i=0;i<V;i++)for(int j=i+1;j<V;j++)all.push_back({i,j});
 vector<Graph> out;int E=all.size();
 for(int em=0;em<(1<<E);em++){
  int m=__builtin_popcount((unsigned)em);if(m<r||m>maxm||!connected_mask(V,all,em))continue;
  Graph G;G.V=V;for(int k=0;k<E;k++)if(em>>k&1)G.e.push_back(all[k]);G.m=m;
  G.baseflag.assign(1<<m,0);for(int s=0;s<(1<<m);s++)if(G.isbase_slow(s)){G.bases.push_back(s);G.baseflag[s]=1;}
  out.push_back(move(G));
 }
 return out;
}
Graph direct_sum(const vector<const Graph*>& cs){
 Graph G;G.V=0;int voff=0;
 for(auto H:cs){for(auto [a,b]:H->e)G.e.push_back({a+voff,b+voff});voff+=H->V;}G.V=voff;G.m=G.e.size();
 G.baseflag.assign(1<<G.m,0);for(int s=0;s<(1<<G.m);s++)if(G.isbase_slow(s)){G.bases.push_back(s);G.baseflag[s]=1;}return G;
}

bool has_bad_block(const Graph&G,long long &quads){
 vector<array<int,3>>MS;for(int a=0;a<4;a++)for(int b=a;b<4;b++)for(int c=b;c<4;c++)MS.push_back({a,b,c});
 int perms[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 int B=G.bases.size();vector<array<int,4>> elems(B);for(int bi=0;bi<B;bi++){int q=0;for(int k=0;k<G.m;k++)if(G.bases[bi]>>k&1)elems[bi][q++]=k;}
 vector<array<int,4>> comp(B);for(int bi=0;bi<B;bi++)for(int miss=0;miss<4;miss++){int s=G.bases[bi]&~(1<<elems[bi][miss]),mask=0;for(int w=0;w<G.m;w++)if(!(s>>w&1)&&G.isbase(s|(1<<w)))mask|=1<<w;comp[bi][miss]=mask;}
 for(int xi=0;xi<B;xi++){
  int Xm=G.bases[xi];auto X=elems[xi];vector<array<unsigned char,20>> prof(B);
  for(int ti=0;ti<B;ti++){auto T=elems[ti];for(int mi=0;mi<20;mi++){unsigned pm=0;for(int miss=0;miss<4;miss++){int targ[3],u=0;for(int j=0;j<4;j++)if(j!=miss)targ[u++]=T[j];for(auto &pp:perms){bool ok=1;for(int z=0;z<3;z++){int x=X[MS[mi][z]],t=targ[pp[z]];if(!G.isbase((Xm&~(1<<x))|(1<<t))){ok=0;break;}}if(ok){pm|=1u<<miss;break;}}}prof[ti][mi]=pm;}}
  for(int yi=0;yi<B;yi++)for(int zi=0;zi<B;zi++)for(int wi=0;wi<B;wi++){quads++;bool success=0;int Wm=G.bases[wi];for(int mi=0;mi<20&&!success;mi++){unsigned py=prof[yi][mi],pz=prof[zi][mi];for(int ym=0;ym<4&&!success;ym++)if(py>>ym&1)for(int zm=0;zm<4;zm++)if(pz>>zm&1)if(comp[yi][ym]&comp[zi][zm]&Wm){success=1;break;}}if(!success){cerr<<"BAD V="<<G.V<<" m="<<G.m<<" B="<<B<<" X="<<G.bases[xi]<<" Y="<<G.bases[yi]<<" Z="<<G.bases[zi]<<" W="<<G.bases[wi]<<"\n";return true;}}
 }
 return false;
}
int main(){
 vector<vector<Graph>> CG(5);for(int r=1;r<=4;r++)CG[r]=connected_graphs_rank(r,7);
 for(int r=1;r<=4;r++)cerr<<"connected rank "<<r<<": "<<CG[r].size()<<" labeled graphs\n";
 vector<vector<int>> parts={{4},{3,1},{2,2},{2,1,1},{1,1,1,1}};
 long long graphs=0,quads=0;
 for(auto part:parts){
  // Cartesian product of connected graph choices for each part; duplicates are harmless.
  vector<const Graph*> choice(part.size());
  function<bool(int)> rec=[&](int k){
   if(k==(int)part.size()){
    Graph G=direct_sum(choice);if(G.m>7)return false;graphs++;long long before=quads;
    if(has_bad_block(G,quads)){cout<<"FOUND\n";return true;}
    return false;
   }
   for(auto &H:CG[part[k]]){choice[k]=&H;if(rec(k+1))return true;}return false;
  };
  if(rec(0))return 0;
  cerr<<"finished partition";for(int r:part)cerr<<' '<<r;cerr<<" cumulative graphs="<<graphs<<" quads="<<quads<<"\n";
 }
 cout<<"NO simple rank-4 graphic 3+1 block counterexample with at most 7 elements; graphs="<<graphs<<" ordered_quadruples="<<quads<<"\n";
}
