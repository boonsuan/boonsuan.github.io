#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif
using namespace std;

struct Matroid {
    bool indep[256]{};
};

struct TripleSolver {
    array<vector<int>,3> T;
    const Matroid &M;
    vector<array<unsigned char,4>> opts[81];

    TripleSolver(array<vector<int>,3> types, const Matroid &mat): T(std::move(types)), M(mat) {
        for (int p=0;p<81;++p) {
            int q=p, typ[4];
            for(int j=0;j<4;++j){ typ[j]=q%3; q/=3; }
            for(int a:T[typ[0]]) for(int b:T[typ[1]]) for(int c:T[typ[2]]) for(int d:T[typ[3]]) {
                int mask=(1<<a)|(1<<b)|(1<<c)|(1<<d);
                if(__builtin_popcount((unsigned)mask)==4 && M.indep[mask])
                    opts[p].push_back({(unsigned char)a,(unsigned char)b,(unsigned char)c,(unsigned char)d});
            }
        }
    }

    bool rec(const int pats[4], const int order[4], int depth, int cm[4]) const {
        if(depth==4) return true;
        const int r=order[depth];
        for(const auto &o: opts[pats[r]]) {
            int nm[4]; bool ok=true;
            for(int j=0;j<4;++j) {
                int bit=1<<o[j];
                if(cm[j]&bit){ok=false;break;}
                nm[j]=cm[j]|bit;
                if(!M.indep[nm[j]]){ok=false;break;}
            }
            if(!ok) continue;
            int old[4];
            for(int j=0;j<4;++j){old[j]=cm[j];cm[j]=nm[j];}
            if(rec(pats,order,depth+1,cm)) return true;
            for(int j=0;j<4;++j) cm[j]=old[j];
        }
        return false;
    }

    bool success(int p0,int p1,int p2,int p3) const {
        int pats[4]={p0,p1,p2,p3};
        int order[4]={0,1,2,3};
        sort(order,order+4,[&](int a,int b){return opts[pats[a]].size()<opts[pats[b]].size();});
        int cm[4]={0,0,0,0};
        return rec(pats,order,0,cm);
    }
};

static int rank_mask(int mask, const int vec[8][4]) {
    // Exact rank over Q using integer fraction-free elimination; entries remain tiny.
    long long a[4][8]{}; int c=0;
    for(int k=0;k<8;++k) if(mask>>k&1) { for(int i=0;i<4;++i) a[i][c]=vec[k][i]; ++c; }
    int r=0;
    for(int j=0;j<c && r<4;++j) {
        int q=-1;
        for(int i=r;i<4;++i) if(a[i][j]!=0){q=i;break;}
        if(q<0) continue;
        for(int z=j;z<c;++z) swap(a[r][z],a[q][z]);
        // eliminate without division
        for(int i=r+1;i<4;++i) if(a[i][j]!=0) {
            long long x=a[r][j], y=a[i][j];
            for(int z=j;z<c;++z) a[i][z]=x*a[i][z]-y*a[r][z];
        }
        ++r;
    }
    return r;
}

int main(){
    const int vec[8][4]={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1},
                         {0,1,0,1},{1,0,1,0},{1,1,0,1},{1,1,1,0}};
    Matroid M;
    vector<int> bases;
    for(int m=0;m<256;++m) {
        int r=rank_mask(m,vec);
        M.indep[m]=(r==__builtin_popcount((unsigned)m));
        if(__builtin_popcount((unsigned)m)==4 && r==4) bases.push_back(m);
    }
    cerr << "bases=" << bases.size() << "\n";
    vector<pair<string,vector<int>>> types={
        {"X",{0,1,2,3}}, {"Y",{3,2,4,5}}, {"Z",{1,0,6,7}}, {"W",{4,5,6,7}}
    };
    for(int omit=0;omit<4;++omit) {
        array<vector<int>,3> tr;
        string name; int t=0;
        for(int i=0;i<4;++i) if(i!=omit){tr[t++]=types[i].second; name+=types[i].first;}
        TripleSolver S(tr,M);
        long long total=0,bad=0;
        atomic<bool> got(false);
        array<int,4> first{-1,-1,-1,-1};
        auto st=chrono::steady_clock::now();
        #pragma omp parallel for schedule(dynamic,1) reduction(+:total,bad)
        for(int p0=0;p0<81;++p0) {
            for(int p1=p0;p1<81;++p1) for(int p2=p1;p2<81;++p2) for(int p3=p2;p3<81;++p3) {
                ++total;
                if(!S.success(p0,p1,p2,p3)) {
                    ++bad;
                    bool expected=false;
                    if(got.compare_exchange_strong(expected,true)) first={p0,p1,p2,p3};
                }
            }
        }
        auto ms=chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now()-st).count();
        cout << name << " total=" << total << " bad=" << bad << " time_ms=" << ms << "\n";
        if(bad) {
            cout << "first row patterns:";
            for(int p:first) cout << ' ' << p;
            cout << "\n";
            for(int p:first){int q=p;for(int j=0;j<4;++j){cout<<(q%3)<<' ';q/=3;}cout<<"\n";}
        }
    }
}
