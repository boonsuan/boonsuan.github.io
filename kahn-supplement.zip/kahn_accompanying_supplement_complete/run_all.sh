#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${BUILD_DIR:-$ROOT/build}"
RESULTS_FILE="${RESULTS_FILE:-$ROOT/verification_results.new.txt}"
CXX="${CXX:-g++}"
PYTHON="${PYTHON:-python3}"
CXXFLAGS_VALUE="${CXXFLAGS:--O3 -std=c++17}"

mkdir -p "$BUILD_DIR"
read -r -a CXXFLAGS_ARRAY <<< "$CXXFLAGS_VALUE"

compile() {
  local source="$1"
  local output="$2"
  shift 2
  "$CXX" "${CXXFLAGS_ARRAY[@]}" "$ROOT/$source" -o "$BUILD_DIR/$output" "$@"
}

compile verify_odd_wheel_family.cpp verify_odd_wheel_family
compile verify_rank3_binary.cpp verify_rank3_binary
compile verify_small_wheel_four_types.cpp verify_small_wheel_four_types
compile verify_graphic_block_minimality_rank4.cpp verify_graphic_block_minimality_rank4
compile verify_graphic_block_minimality_rank5.cpp verify_graphic_block_minimality_rank5
compile verify_rank3_projective_block.cpp verify_rank3_projective_block

if [[ "${OPENMP:-0}" == "1" ]]; then
  compile verify_four_special_bases.cpp verify_four_special_bases -fopenmp
else
  compile verify_four_special_bases.cpp verify_four_special_bases
fi

{
  echo "=== verify_even_wheel_family.py ==="
  "$PYTHON" "$ROOT/verify_even_wheel_family.py"
  echo

  echo "=== verify_odd_wheel_family.cpp ==="
  "$BUILD_DIR/verify_odd_wheel_family"
  echo

  echo "=== verify_rank3_binary.cpp ==="
  "$BUILD_DIR/verify_rank3_binary"
  echo

  echo "=== verify_four_special_bases.cpp ==="
  "$BUILD_DIR/verify_four_special_bases"
  echo

  echo "=== verify_small_wheel_four_types.cpp (rank 4) ==="
  "$BUILD_DIR/verify_small_wheel_four_types" 4
  echo

  echo "=== verify_small_wheel_four_types.cpp (rank 5) ==="
  "$BUILD_DIR/verify_small_wheel_four_types" 5
  echo

  echo "=== verify_graphic_block_minimality_rank4.cpp ==="
  "$BUILD_DIR/verify_graphic_block_minimality_rank4"
  echo

  echo "=== verify_graphic_block_minimality_rank5.cpp ==="
  "$BUILD_DIR/verify_graphic_block_minimality_rank5"
  echo

  echo "=== verify_rank3_projective_block.cpp (additional check; not used in manuscript) ==="
  "$BUILD_DIR/verify_rank3_projective_block" 2
  "$BUILD_DIR/verify_rank3_projective_block" 3
} | tee "$RESULTS_FILE"

printf '\nWrote %s\n' "$RESULTS_FILE"
