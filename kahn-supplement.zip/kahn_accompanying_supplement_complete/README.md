# Computational supplement

This directory contains the exact programs used for the computer-assisted statements in the manuscript **Graphic counterexamples to Kahn's basis conjecture in every rank at least four**. None of the programs uses floating-point arithmetic.

The wheel counterexamples themselves are proved deductively in the paper. The wheel programs below are independent finite checks of the definitions, exchange relations, and boundary criterion in several ranks.


## Archive contents

This ZIP contains the following files:

- `README.md`
- `run_all.sh`
- `verification_results.txt`
- `SHA256SUMS`
- `verify_even_wheel_family.py`
- `verify_odd_wheel_family.cpp`
- `verify_rank3_binary.cpp`
- `verify_four_special_bases.cpp`
- `verify_small_wheel_four_types.cpp`
- `verify_graphic_block_minimality_rank4.cpp`
- `verify_graphic_block_minimality_rank5.cpp`
- `verify_rank3_projective_block.cpp`

`run_all.sh` writes a fresh transcript to `verification_results.new.txt`; the bundled `verification_results.txt` is the recorded reference run. Build products are placed in `build/`, which is not included in the archive.

## Programs used in stated results

- `verify_rank3_binary.cpp` exhausts all `3 x 3` arrays of bases of the Fano matroid. It reduces the first row by the 168 automorphisms of the Fano matroid and the six column permutations. This is the computation in the Fano-matroid proposition. The deduction for all rank-three binary matroids is mathematical and appears in the manuscript.

- `verify_four_special_bases.cpp` checks, for each three-element subset of the four displayed rank-four bases `X,Y,Z,W`, every `4 x 4` array up to row permutation.

- `verify_small_wheel_four_types.cpp` checks all block arrays of spanning trees in the wheels of ranks 4 and 5, after reducing `X` by the dihedral group and identifying transposed arrays. It verifies that every counterexample encountered uses four distinct spanning trees.

- `verify_graphic_block_minimality_rank4.cpp` enumerates simple rank-four graphic matroid models on at most seven elements and every ordered quadruple of bases in the block form. It proves the restricted eight-element minimality statement.

- `verify_graphic_block_minimality_rank5.cpp` generates, up to vertex relabeling, all connected simple graphs of ranks 1 through 5 needed to form direct sums of total rank 5 and at most nine edges. It then applies the exact block criterion to every resulting graph model. It proves the restricted ten-element minimality statement.

## Independent finite checks of the infinite constructions

- `verify_even_wheel_family.py` reconstructs the even-wheel examples, recomputes their exchange data, and exhausts the boundary criterion in ranks 4, 6, 8, and 10.

- `verify_odd_wheel_family.cpp` reconstructs the odd-wheel examples and exhausts the boundary criterion in ranks 5, 7, 9, and 11. For rank 5 it also prints the four spanning trees in edge notation.

## Additional restricted check

- `verify_rank3_projective_block.cpp` exhausts block arrays in `PG(2,2)` and `PG(2,3)`. This computation is not used in a theorem of the manuscript.

## Build and run

The convenience script `run_all.sh` compiles and runs all programs:

```sh
./run_all.sh
```

Equivalently, the C++ sources can be compiled with a command of the form

```sh
g++ -O3 -std=c++17 source.cpp -o program
```

The source `verify_four_special_bases.cpp` may be compiled with `-fopenmp` to parallelize the search. Omitting OpenMP runs the same exact search serially.

Recorded output from a fresh run is in `verification_results.txt`. Elapsed-time lines are machine-dependent; the enumerated counts and final conclusions are deterministic.

## Environment used for the recorded run

- g++ 14.2.0
- Python 3.13.5
- 64-bit Linux
