#include <bits/stdc++.h>
using namespace std;
struct Pt{int a[3];};
int modinv(int a,int p){for(int x=1;x<p;x++)if(a*x%p==1)return x;return 0;}
int det3(const Pt&A,const Pt&B,const Pt&C,int p){long long d=1LL*A.a[0]*(B.a[1]*C.a[2]-B.a[2]*C.a[1])-1LL*A.a[1]*(B.a[0]*C.a[2]-B.a[2]*C.a[0])+1LL*A.a[2]*(B.a[0]*C.a[1]-B.a[1]*C.a[0]);d%=p;if(d<0)d+=p;return d;}
int main(int argc,char**argv){int p=argc>1?atoi(argv[1]):3;vector<Pt>P;
 for(int x=0;x<p;x++)for(int y=0;y<p;y++)for(int z=0;z<p;z++)if(x||y||z){int first=x?x:(y?y:z);int inv=modinv(first,p);Pt q{{x*inv%p,y*inv%p,z*inv%p}};bool seen=0;for(auto&r:P)if(equal(begin(q.a),end(q.a),begin(r.a))){seen=1;break;}if(!seen)P.push_back(q);}
 int N=P.size();vector<array<int,3>> B;
 static bool indep[64][64][64];
 for(int i=0;i<N;i++)for(int j=0;j<N;j++)for(int k=0;k<N;k++)indep[i][j][k]=(i!=j&&i!=k&&j!=k&&det3(P[i],P[j],P[k],p)!=0);
 for(int i=0;i<N;i++)for(int j=i+1;j<N;j++)for(int k=j+1;k<N;k++)if(indep[i][j][k])B.push_back({i,j,k});
 cerr<<"p="<<p<<" points="<<N<<" bases="<<B.size()<<"\n";
 // canonical X first basis; PGL transitive on bases
 auto X=B[0];int nb=B.size();
 // M types: unordered pairs of X positions (with repeat)
 vector<pair<int,int>> Ms;for(int a=0;a<3;a++)for(int b=a;b<3;b++)Ms.push_back({a,b});
 vector<array<unsigned char,6>> prof(nb); // bitmask of missing positions possible for each M
 for(int bi=0;bi<nb;bi++){
  auto T=B[bi];
  for(int mi=0;mi<6;mi++){
   auto [xa,xb]=Ms[mi];unsigned mask=0;
   for(int miss=0;miss<3;miss++){
    int q[2],u=0;for(int t=0;t<3;t++)if(t!=miss)q[u++]=T[t];
    bool ok=(indep[X[(xa+1)%3]][X[(xa+2)%3]][q[0]] && indep[X[(xb+1)%3]][X[(xb+2)%3]][q[1]]) ||
            (indep[X[(xa+1)%3]][X[(xa+2)%3]][q[1]] && indep[X[(xb+1)%3]][X[(xb+2)%3]][q[0]]);
    // Above complement indexing only correct if (xa+1),(xa+2) are other positions mod3: yes.
    if(ok)mask|=1u<<miss;
   }
   prof[bi][mi]=mask;
  }
 }
 long long checked=0;auto st=chrono::steady_clock::now();
 for(int yi=0;yi<nb;yi++)for(int zi=0;zi<nb;zi++){
  // quick: if any M profiles empty, just skip that M, but all may
  for(int wi=0;wi<nb;wi++){
   bool success=false;
   auto Y=B[yi],Z=B[zi],W=B[wi];
   for(int mi=0;mi<6&&!success;mi++){
    unsigned py=prof[yi][mi],pz=prof[zi][mi];
    for(int ym=0;ym<3&&!success;ym++)if(py>>ym&1)for(int zm=0;zm<3&&!success;zm++)if(pz>>zm&1){
      int ya=-1,yb=-1,za=-1,zb=-1,u=0;for(int t=0;t<3;t++)if(t!=ym)(u++?yb:ya)=Y[t];u=0;for(int t=0;t<3;t++)if(t!=zm)(u++?zb:za)=Z[t];
      for(int t=0;t<3;t++){int w=W[t];if(w==ya||w==yb||w==za||w==zb)continue;if(indep[ya][yb][w]&&indep[za][zb][w]){success=true;break;}}
    }
   }
   checked++;
   if(!success){
    cout<<"FOUND bad block Y="<<yi<<" Z="<<zi<<" W="<<wi<<"\n";
    auto pr=[&](auto T){for(int x:T)cout<<x<<' ';cout<<'\n';};cout<<"X ";pr(X);cout<<"Y ";pr(Y);cout<<"Z ";pr(Z);cout<<"W ";pr(W);return 0;
   }
  }
 }
 auto ms=chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now()-st).count();
 cout<<"NO bad block arrays; checked="<<checked<<" time_ms="<<ms<<"\n";
}
