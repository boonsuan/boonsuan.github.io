#include <bits/stdc++.h>
using namespace std; using U64=uint64_t;
struct Graph{int V,E,r;vector<pair<int,int>> ends;};
bool tree(const Graph&g,U64 M){if(__builtin_popcountll(M)!=g.r)return false;vector<int>p(g.V);iota(p.begin(),p.end(),0);function<int(int)>f=[&](int x){return p[x]==x?x:p[x]=f(p[x]);};for(int e=0;e<g.E;e++)if(M>>e&1){auto[a,b]=g.ends[e];a=f(a);b=f(b);if(a==b)return false;p[b]=a;}return true;}
vector<int> bits(U64 m){vector<int>v;while(m){int e=__builtin_ctzll(m);m&=m-1;v.push_back(e);}return v;}
vector<vector<int>> oms(int n){vector<vector<int>>o;vector<int>c(n-1);function<void(int,int)>rec=[&](int k,int lo){if(k==n-1){o.push_back(c);return;}for(int x=lo;x<n;x++){c[k]=x;rec(k+1,x);}};rec(0,0);return o;}
U64 possible(const Graph&g,U64 X,U64 Y,const vector<int>&xe,const vector<int>&ye,const vector<int>&om){int n=xe.size();vector<U64>E(n);for(int i=0;i<n;i++)for(int j=0;j<n;j++)if(tree(g,(X&~(1ULL<<xe[i]))|(1ULL<<ye[j])))E[i]|=1ULL<<j;U64 ans=0;for(int omit=0;omit<n;omit++){vector<int>a=om;sort(a.begin(),a.end(),[&](int u,int v){return __builtin_popcountll(E[u]&~(1ULL<<omit))<__builtin_popcountll(E[v]&~(1ULL<<omit));});bool ok=0;function<void(int,U64)>rec=[&](int k,U64 used){if(ok)return;if(k==n-1){ok=1;return;}U64 q=E[a[k]]&~used&~(1ULL<<omit);while(q){int j=__builtin_ctzll(q);q&=q-1;rec(k+1,used|(1ULL<<j));}};rec(0,0);if(ok)ans|=1ULL<<ye[omit];}return ans;}
string lab(int e,int n){return string(e<n?"s":"r")+to_string(e<n?e:e-n);} 
int main(){for(int n:{5,7,9,11}){if(2*n>63)break;Graph g{n+1,2*n,n,{}};for(int i=0;i<n;i++)g.ends.push_back({n,i});for(int i=0;i<n;i++)g.ends.push_back({i,(i+1)%n});U64 X=0,Y=0,Z=0,W=0;int m=(n-1)/2;for(int i=0;i<n;i++){
 if(i%2==0)X|=1ULL<<i; // even spokes incl 0
 if(i%2==1){Y|=1ULL<<i;W|=1ULL<<i;} // odd spokes
 if(i%2==0 && i>0) Z|=1ULL<<i; // positive even spokes
 if(i%2==0 && i<n-1){X|=1ULL<<(n+i);Y|=1ULL<<(n+i);} // even rim except closing in X, all nonclosing evens in Y
 if(i%2==1){Z|=1ULL<<(n+i);W|=1ULL<<(n+i);} // odd rim
 }
 Y|=1ULL<<(n+n-1); Z|=1ULL<<(n+n-1); W|=1ULL<<(n+n-1); // closing rim
 cerr<<"rank "<<n<<" trees="<<tree(g,X)<<tree(g,Y)<<tree(g,Z)<<tree(g,W)<<"\n";
 auto xe=bits(X),ye=bits(Y),ze=bits(Z),we=bits(W);auto O=oms(n);long long checked=0;bool succ=false;
 vector<array<U64,64>> cy(1),cz(1); // global omitted edge -> completion mask
 array<U64,64> CY{},CZ{};
 for(int e:ye)for(int w:we)if(tree(g,(Y&~(1ULL<<e))|(1ULL<<w)))CY[e]|=1ULL<<w;
 for(int e:ze)for(int w:we)if(tree(g,(Z&~(1ULL<<e))|(1ULL<<w)))CZ[e]|=1ULL<<w;
 for(auto&om:O){checked++;U64 my=possible(g,X,Y,xe,ye,om);if(!my)continue;U64 mz=possible(g,X,Z,xe,ze,om);if(!mz)continue;U64 uy=0,t=my;while(t){int e=__builtin_ctzll(t);t&=t-1;uy|=CY[e];}t=mz;while(t){int e=__builtin_ctzll(t);t&=t-1;if(uy&CZ[e]){succ=true;cerr<<"boundary success rank="<<n<<"\n";break;}}if(succ)break;}
 cout<<"rank "<<n<<": "<<(succ?"HAS boundary solution":"NO boundary solution")<<"; omissions="<<checked<<"\n";
 if(n==5){for(auto [name,M]:vector<pair<string,U64>>{{"X",X},{"Y",Y},{"Z",Z},{"W",W}}){cout<<name<<"={";bool first=1;for(int e:bits(M)){if(!first)cout<<",";first=0;cout<<lab(e,n);}cout<<"}\n";}}
 }}
