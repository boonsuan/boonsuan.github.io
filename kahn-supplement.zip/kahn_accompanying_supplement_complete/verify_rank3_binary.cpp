#include <bits/stdc++.h>
using namespace std;
struct Bits{uint64_t w[6]{};};
int main(){
 auto basepts=[](int a,int b,int c){if(a==b||a==c||b==c)return false;return ((a+1)^(b+1)^(c+1))!=0;};
 vector<int>B;for(int a=0;a<7;a++)for(int b=a+1;b<7;b++)for(int c=b+1;c<7;c++)if(basepts(a,b,c))B.push_back((1<<a)|(1<<b)|(1<<c));int NB=B.size();cerr<<"bases="<<NB<<"\n";
 const int P=28*28*28,T=343,W=6;
 vector<Bits> opts(P);vector<vector<unsigned short>> ol(P);
 auto tid=[](int a,int b,int c){return a+7*b+49*c;};auto pid=[](int a,int b,int c){return a+28*b+784*c;};
 for(int a=0;a<NB;a++)for(int b=0;b<NB;b++)for(int c=0;c<NB;c++){int p=pid(a,b,c);for(int x=0;x<7;x++)if(B[a]>>x&1)for(int y=0;y<7;y++)if(B[b]>>y&1)for(int z=0;z<7;z++)if(B[c]>>z&1)if(basepts(x,y,z)){int t=tid(x,y,z);opts[p].w[t>>6]|=1ull<<(t&63);ol[p].push_back(t);}}
 vector<Bits> comp(T*T);
 for(int a=0;a<T;a++){int a0=a%7,a1=a/7%7,a2=a/49;for(int b=0;b<T;b++){int b0=b%7,b1=b/7%7,b2=b/49;Bits&q=comp[a*T+b];for(int c0=0;c0<7;c0++)if(basepts(a0,b0,c0))for(int c1=0;c1<7;c1++)if(basepts(a1,b1,c1))for(int c2=0;c2<7;c2++)if(basepts(a2,b2,c2)){int c=tid(c0,c1,c2);q.w[c>>6]|=1ull<<(c&63);}}}
 // GL(3,2) permutations of seven nonzero vectors.
 vector<array<int,7>> autos;
 for(int c0=1;c0<8;c0++)for(int c1=1;c1<8;c1++)for(int c2=1;c2<8;c2++)if(basepts(c0-1,c1-1,c2-1)){
  array<int,7>p{};for(int v=1;v<8;v++){int out=0;if(v&1)out^=c0;if(v&2)out^=c1;if(v&4)out^=c2;p[v-1]=out-1;}autos.push_back(p);
 }
 cerr<<"autos="<<autos.size()<<"\n";
 int cps[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 vector<array<int,28>>bm(autos.size());for(int g=0;g<(int)autos.size();g++)for(int i=0;i<NB;i++){int s=0;for(int x=0;x<7;x++)if(B[i]>>x&1)s|=1<<autos[g][x];bm[g][i]=find(B.begin(),B.end(),s)-B.begin();}
 vector<int>reps;vector<char>seen(P);for(int p=0;p<P;p++)if(!seen[p]){int q=p,bx[3];for(int j=0;j<3;j++){bx[j]=q%28;q/=28;}int canon=P;for(int g=0;g<(int)autos.size();g++)for(auto &cp:cps){int t=pid(bm[g][bx[cp[0]]],bm[g][bx[cp[1]]],bm[g][bx[cp[2]]]);seen[t]=1;canon=min(canon,t);}if(p==canon)reps.push_back(p);}cerr<<"first-row orbits="<<reps.size()<<"\n";
 long long pairs=0,tests=0;auto st=chrono::steady_clock::now();
 for(int ri=0;ri<(int)reps.size();ri++){int p=reps[ri];for(int q=0;q<P;q++){pairs++;Bits allowed{};for(auto a:ol[p])for(auto b:ol[q]){Bits&x=comp[a*T+b];for(int k=0;k<W;k++)allowed.w[k]|=x.w[k];}int bad=-1;for(int r=0;r<P;r++){tests++;bool hit=0;for(int k=0;k<W;k++)if(allowed.w[k]&opts[r].w[k]){hit=1;break;}if(!hit){bad=r;break;}}if(bad>=0){cout<<"FOUND bad "<<p<<' '<<q<<' '<<bad<<"\n";return 0;}}
  cerr<<"orbit "<<ri+1<<'/'<<reps.size()<<" elapsed_ms="<<chrono::duration_cast<chrono::milliseconds>(chrono::steady_clock::now()-st).count()<<"\n";
 }
 cout<<"NO bad 3x3 array in Fano matroid; first_row_orbits="<<reps.size()<<" row_pairs="<<pairs<<" third_pattern_tests="<<tests<<"\n";
}
