#include <algorithm>
#include <array>
#include <cstdint>
#include <functional>
#include <iostream>
#include <map>
#include <numeric>
#include <utility>
#include <vector>

using std::array;
using std::cout;
using std::cerr;
using std::pair;
using std::vector;

struct Graph {
    int vertices = 0;
    int edges_count = 0;
    vector<pair<int, int>> edges;
    vector<int> bases;
    vector<unsigned char> is_basis;
    vector<array<int, 5>> basis_edges;
};

static int find_root(vector<int>& parent, int x) {
    return parent[x] == x ? x : parent[x] = find_root(parent, parent[x]);
}

static bool is_forest_basis(const Graph& graph, int mask) {
    if (__builtin_popcount(static_cast<unsigned>(mask)) != 5) {
        return false;
    }
    vector<int> parent(graph.vertices);
    std::iota(parent.begin(), parent.end(), 0);
    for (int e = 0; e < graph.edges_count; ++e) {
        if (!(mask & (1 << e))) {
            continue;
        }
        auto [u, v] = graph.edges[e];
        u = find_root(parent, u);
        v = find_root(parent, v);
        if (u == v) {
            return false;
        }
        parent[u] = v;
    }
    // Every generated ambient graph has total graphic rank five.  Hence an
    // acyclic five-edge set is a basis of its cycle matroid.
    return true;
}

static bool connected_mask(int vertices, const vector<pair<int, int>>& all_edges,
                           int mask) {
    vector<int> parent(vertices);
    std::iota(parent.begin(), parent.end(), 0);
    for (int e = 0; e < static_cast<int>(all_edges.size()); ++e) {
        if (!(mask & (1 << e))) {
            continue;
        }
        auto [u, v] = all_edges[e];
        u = find_root(parent, u);
        v = find_root(parent, v);
        parent[u] = v;
    }
    const int root = find_root(parent, 0);
    for (int v = 1; v < vertices; ++v) {
        if (find_root(parent, v) != root) {
            return false;
        }
    }
    return true;
}

static int relabel_mask(int mask, const vector<int>& edge_permutation) {
    int image = 0;
    for (int e = 0; e < static_cast<int>(edge_permutation.size()); ++e) {
        if (mask & (1 << e)) {
            image |= 1 << edge_permutation[e];
        }
    }
    return image;
}

static vector<Graph> connected_graphs_of_rank(int rank, int edge_limit) {
    const int vertices = rank + 1;
    vector<pair<int, int>> all_edges;
    for (int u = 0; u < vertices; ++u) {
        for (int v = u + 1; v < vertices; ++v) {
            all_edges.push_back({u, v});
        }
    }

    std::map<pair<int, int>, int> edge_index;
    for (int e = 0; e < static_cast<int>(all_edges.size()); ++e) {
        edge_index[all_edges[e]] = e;
    }
    vector<vector<int>> edge_permutations;
    vector<int> permutation(vertices);
    std::iota(permutation.begin(), permutation.end(), 0);
    do {
        vector<int> edge_permutation(all_edges.size());
        for (int e = 0; e < static_cast<int>(all_edges.size()); ++e) {
            int u = permutation[all_edges[e].first];
            int v = permutation[all_edges[e].second];
            if (u > v) {
                std::swap(u, v);
            }
            edge_permutation[e] = edge_index[{u, v}];
        }
        edge_permutations.push_back(std::move(edge_permutation));
    } while (std::next_permutation(permutation.begin(), permutation.end()));

    vector<Graph> result;
    const int limit = 1 << static_cast<int>(all_edges.size());
    for (int mask = 0; mask < limit; ++mask) {
        const int edge_count = __builtin_popcount(static_cast<unsigned>(mask));
        if (edge_count < rank || edge_count > edge_limit ||
            !connected_mask(vertices, all_edges, mask)) {
            continue;
        }
        int canonical = mask;
        for (const auto& edge_permutation : edge_permutations) {
            canonical = std::min(canonical,
                                 relabel_mask(mask, edge_permutation));
        }
        if (mask != canonical) {
            continue;
        }

        Graph graph;
        graph.vertices = vertices;
        for (int e = 0; e < static_cast<int>(all_edges.size()); ++e) {
            if (mask & (1 << e)) {
                graph.edges.push_back(all_edges[e]);
            }
        }
        graph.edges_count = static_cast<int>(graph.edges.size());
        result.push_back(std::move(graph));
    }
    return result;
}

static Graph direct_sum(const vector<const Graph*>& components) {
    Graph result;
    int vertex_offset = 0;
    for (const Graph* component : components) {
        for (auto [u, v] : component->edges) {
            result.edges.push_back({u + vertex_offset, v + vertex_offset});
        }
        vertex_offset += component->vertices;
    }
    result.vertices = vertex_offset;
    result.edges_count = static_cast<int>(result.edges.size());
    return result;
}

static void enumerate_bases(Graph& graph) {
    graph.is_basis.assign(1 << graph.edges_count, 0);
    for (int mask = 0; mask < (1 << graph.edges_count); ++mask) {
        if (!is_forest_basis(graph, mask)) {
            continue;
        }
        graph.is_basis[mask] = 1;
        graph.bases.push_back(mask);
        array<int, 5> edges{};
        int position = 0;
        for (int e = 0; e < graph.edges_count; ++e) {
            if (mask & (1 << e)) {
                edges[position++] = e;
            }
        }
        graph.basis_edges.push_back(edges);
    }
}

static bool matching_exists(const array<int, 4>& omissions,
                            const array<int, 5>& target,
                            int missing_position,
                            const vector<vector<unsigned char>>& exchange) {
    int target_edges[4];
    int count = 0;
    for (int j = 0; j < 5; ++j) {
        if (j != missing_position) {
            target_edges[count++] = target[j];
        }
    }
    for (int p0 = 0; p0 < 4; ++p0) {
        for (int p1 = 0; p1 < 4; ++p1) {
            if (p1 == p0) continue;
            for (int p2 = 0; p2 < 4; ++p2) {
                if (p2 == p0 || p2 == p1) continue;
                const int p3 = 6 - p0 - p1 - p2;
                if (exchange[omissions[0]][target_edges[p0]] &&
                    exchange[omissions[1]][target_edges[p1]] &&
                    exchange[omissions[2]][target_edges[p2]] &&
                    exchange[omissions[3]][target_edges[p3]]) {
                    return true;
                }
            }
        }
    }
    return false;
}

static bool has_bad_block(Graph& graph, long long& xyz_cases) {
    enumerate_bases(graph);
    const int basis_count = static_cast<int>(graph.bases.size());

    vector<array<int, 4>> omission_multisets;
    for (int a = 0; a < 5; ++a)
        for (int b = a; b < 5; ++b)
            for (int c = b; c < 5; ++c)
                for (int d = c; d < 5; ++d)
                    omission_multisets.push_back({a, b, c, d});

    for (int x_index = 0; x_index < basis_count; ++x_index) {
        const int x_mask = graph.bases[x_index];
        const auto x_edges = graph.basis_edges[x_index];
        vector<vector<unsigned char>> exchange(5,
                                                vector<unsigned char>(graph.edges_count));
        for (int x = 0; x < 5; ++x) {
            for (int y = 0; y < graph.edges_count; ++y) {
                exchange[x][y] = graph.is_basis[
                    (x_mask & ~(1 << x_edges[x])) | (1 << y)];
            }
        }

        // gamma[T][omega] is the bit mask of elements that can complete the
        // target boundary basis T for omission multiset omega.
        vector<array<unsigned short, 70>> gamma(basis_count);
        for (int t_index = 0; t_index < basis_count; ++t_index) {
            const auto target = graph.basis_edges[t_index];
            unsigned short corner[5]{};
            for (int missing = 0; missing < 5; ++missing) {
                const int four_set = graph.bases[t_index] & ~(1 << target[missing]);
                for (int w = 0; w < graph.edges_count; ++w) {
                    if (graph.is_basis[four_set | (1 << w)]) {
                        corner[missing] |= static_cast<unsigned short>(1u << w);
                    }
                }
            }
            for (int omega = 0; omega < 70; ++omega) {
                unsigned short possible = 0;
                for (int missing = 0; missing < 5; ++missing) {
                    if (matching_exists(omission_multisets[omega], target,
                                        missing, exchange)) {
                        possible |= corner[missing];
                    }
                }
                gamma[t_index][omega] = possible;
            }
        }

        // Transposition interchanges Y and Z, so take y_index <= z_index.
        for (int y_index = 0; y_index < basis_count; ++y_index) {
            for (int z_index = y_index; z_index < basis_count; ++z_index) {
                ++xyz_cases;
                unsigned short common_corner = 0;
                for (int omega = 0; omega < 70; ++omega) {
                    common_corner |= gamma[y_index][omega] & gamma[z_index][omega];
                }
                for (int w_index = 0; w_index < basis_count; ++w_index) {
                    if ((graph.bases[w_index] & common_corner) == 0) {
                        cerr << "Counterexample in a graph with "
                             << graph.edges_count << " edges\n";
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

int main() {
    vector<vector<Graph>> connected(6);
    for (int rank = 1; rank <= 5; ++rank) {
        connected[rank] = connected_graphs_of_rank(rank, 9);
        cerr << "connected rank " << rank << ": "
             << connected[rank].size() << " unlabeled graphs\n";
    }

    const vector<vector<int>> partitions = {
        {5}, {4, 1}, {3, 2}, {3, 1, 1},
        {2, 2, 1}, {2, 1, 1, 1}, {1, 1, 1, 1, 1}
    };

    long long graph_models = 0;
    long long xyz_cases = 0;
    for (const auto& partition : partitions) {
        vector<const Graph*> choice(partition.size());
        vector<int> chosen_index(partition.size(), 0);
        std::function<bool(int)> recurse = [&](int position) {
            if (position == static_cast<int>(partition.size())) {
                Graph graph = direct_sum(choice);
                if (graph.edges_count > 9) {
                    return false;
                }
                ++graph_models;
                if (has_bad_block(graph, xyz_cases)) {
                    return true;
                }
                return false;
            }
            const int rank = partition[position];
            int first = 0;
            if (position > 0 && partition[position - 1] == rank) {
                first = chosen_index[position - 1];
            }
            for (int index = first;
                 index < static_cast<int>(connected[rank].size()); ++index) {
                choice[position] = &connected[rank][index];
                chosen_index[position] = index;
                if (recurse(position + 1)) {
                    return true;
                }
            }
            return false;
        };
        if (recurse(0)) {
            cout << "FOUND\n";
            return 1;
        }
    }

    cout << "NO simple rank-5 graphic 3+1 block counterexample with at most "
         << "9 elements; graph_models=" << graph_models
         << " X_unordered_YZ_cases=" << xyz_cases << "\n";
    return 0;
}
