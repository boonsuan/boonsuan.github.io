#!/usr/bin/env python3
"""
Exact verification for the numerical constants in kalton_sub20_final.tex.

The script verifies two things.

1. The four expander parameter triples satisfy the Pippenger entropy
   conditions used in the paper.  Logarithms of rational numbers are enclosed
   by exact rational intervals, using

       log z = 2 * sum_{n>=0} t^(2n+1)/(2n+1),  t=(z-1)/(z+1),

   after range reduction to 1 <= z <= 2.  The positive tail is bounded by a
   geometric series.  No floating-point arithmetic is used in the sign checks.

2. The final case bounds are recomputed exactly with rational arithmetic.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, getcontext
from functools import lru_cache
from fractions import Fraction
from typing import Tuple

Interval = Tuple[Fraction, Fraction]
N_TERMS = 90
getcontext().prec = 50


def iadd(*intervals: Interval) -> Interval:
    return (sum(i[0] for i in intervals), sum(i[1] for i in intervals))


def isub(a: Interval, b: Interval) -> Interval:
    return (a[0] - b[1], a[1] - b[0])


def imul_scalar(c: Fraction, x: Interval) -> Interval:
    if c >= 0:
        return (c * x[0], c * x[1])
    return (c * x[1], c * x[0])


def atanh_log_interval(y: Fraction, n_terms: int = N_TERMS) -> Interval:
    """Return an exact rational interval for log(y), for 1 <= y <= 2."""
    if y == 1:
        return (Fraction(0), Fraction(0))
    if not (Fraction(1) <= y <= Fraction(2)):
        raise ValueError(f"range reduction failed: y={y}")
    t = (y - 1) / (y + 1)
    total = Fraction(0)
    power = t
    t2 = t * t
    for n in range(n_terms):
        total += Fraction(2) * power / Fraction(2 * n + 1)
        power *= t2
    # Positive tail: 2 * sum_{n>=N} t^(2n+1)/(2n+1)
    # <= 2*t^(2N+1)/((2N+1)*(1-t^2)).
    tail = Fraction(2) * power / (Fraction(2 * n_terms + 1) * (1 - t2))
    return (total, total + tail)


LOG2_INTERVAL = atanh_log_interval(Fraction(2))


@lru_cache(maxsize=None)
def log_interval(z: Fraction) -> Interval:
    """Return an exact rational interval for log(z), z > 0."""
    if z <= 0:
        raise ValueError("log is only defined for positive rationals")
    if z == 1:
        return (Fraction(0), Fraction(0))

    y = z
    k = 0
    while y < 1:
        y *= 2
        k -= 1
    while y > 2:
        y /= 2
        k += 1

    return iadd(imul_scalar(Fraction(k), LOG2_INTERVAL), atanh_log_interval(y))


def h_interval(a: Fraction, b: Fraction) -> Interval:
    """Exact interval for h(a,b)=a log a-b log b-(a-b)log(a-b)."""
    if not (a > b > 0):
        raise ValueError(f"need a>b>0, got a={a}, b={b}")
    return iadd(
        imul_scalar(a, log_interval(a)),
        imul_scalar(-b, log_interval(b)),
        imul_scalar(-(a - b), log_interval(a - b)),
    )


def phi_interval(x: Fraction, r: int, theta: Fraction) -> Interval:
    rr = Fraction(r)
    return iadd(
        h_interval(Fraction(1), x),
        h_interval(theta, x),
        h_interval(rr * x / theta, rr * x),
        imul_scalar(Fraction(-1), h_interval(rr, rr * x)),
    )


def dec(q: Fraction, digits: int = 14) -> str:
    value = Decimal(q.numerator) / Decimal(q.denominator)
    return f"{value:.{digits}f}"


@dataclass(frozen=True)
class ExpanderTriple:
    name: str
    alpha: Fraction
    r: int
    theta: Fraction


def certify_expander(triple: ExpanderTriple, delta: Fraction) -> None:
    ph_delta = phi_interval(delta, triple.r, triple.theta)
    ph_alpha = phi_interval(triple.alpha, triple.r, triple.theta)

    # Phi''(x)=(r-2)/x+(r-1)/(1-x)-1/(theta-x).
    # Discarding the positive middle term gives a convenient lower bound on
    # [delta,alpha].
    convex_lb = Fraction(triple.r - 2, 1) / triple.alpha - Fraction(1, 1) / (triple.theta - triple.alpha)

    # The proof uses e^2 < 8, so this rational upper bound implies the
    # required small-x condition e^2 theta^(1-r) delta^(r-2) < 1.
    small_base_bound = Fraction(8) * (triple.theta ** (1 - triple.r)) * (delta ** (triple.r - 2))

    print(f"{triple.name}: alpha={triple.alpha}, r={triple.r}, theta={triple.theta}")
    print(f"    Phi(delta) in [{dec(ph_delta[0])}, {dec(ph_delta[1])}]")
    print(f"    Phi(alpha) in [{dec(ph_alpha[0])}, {dec(ph_alpha[1])}]")
    print(f"    lower bound for Phi'' = {convex_lb} = {dec(convex_lb)}")
    print(f"    8*theta^(1-r)*delta^(r-2) = {small_base_bound} = {dec(small_base_bound)}")

    assert ph_delta[1] < 0, f"Phi(delta) is not certified negative for {triple.name}"
    assert ph_alpha[1] < 0, f"Phi(alpha) is not certified negative for {triple.name}"
    assert convex_lb > 0, f"convexity lower bound failed for {triple.name}"
    assert small_base_bound < 1, f"small-x condition failed for {triple.name}"
    print("    certified = True")


def balance_decreasing_increasing(A: Fraction, a: Fraction, C: Fraction, b: Fraction) -> Fraction:
    """Return sup_{x>=0} min(A-a*x, C+b*x), in the crossing case."""
    crossing = (A - C) / (a + b)
    if crossing < 0:
        return min(A, C)
    return A - a * crossing


def one_sided_bound(D: Fraction, r1: int, theta1: Fraction, r2: int, theta2: Fraction) -> Fraction:
    A = (D + 2 * r1 - 1 - theta1) / (1 - theta1)
    a = theta1 / (1 - theta1)
    C = (2 * r2 - 1 - theta2) / (1 - theta2)
    b = Fraction(1, 1) / (1 - theta2)
    return balance_decreasing_increasing(A, a, C, b)


def two_sided_bound(H: Fraction, r1: int, theta1: Fraction, r2: int, theta2: Fraction) -> Fraction:
    A = (H + 2 * r1 - 1 - theta1) / (1 - theta1)
    a = theta1 / (1 - theta1)
    C = (2 * r2 - 1 - theta2) / (1 - theta2)
    b = Fraction(1, 1) / (1 - theta2)
    return balance_decreasing_increasing(A, a, C, b)


def main() -> None:
    delta = Fraction(1, 100)
    triples = [
        ExpanderTriple("E1", Fraction(1000, 9261), 4, Fraction(4, 11)),
        ExpanderTriple("E2", Fraction(2750, 9261), 4, Fraction(4, 7)),
        ExpanderTriple("E3", Fraction(1331, 9261), 4, Fraction(2, 5)),
        ExpanderTriple("E4", Fraction(6655, 18522), 5, Fraction(5, 9)),
    ]

    print("Expander entropy certificates")
    print("------------------------------")
    for triple in triples:
        certify_expander(triple, delta)

    q0 = Fraction(10, 21)
    case1_source_deficit = 4 + 6 * q0       # 48/7
    case2_half_sum = 7 - 3 * q0             # 39/7

    case1 = one_sided_bound(case1_source_deficit, 4, Fraction(4, 11), 4, Fraction(4, 7))
    case2 = two_sided_bound(case2_half_sum, 4, Fraction(2, 5), 5, Fraction(5, 9))
    final = max(case1, case2)

    case1_first_constant = (case1_source_deficit + 8 - 1 - Fraction(4, 11)) / (1 - Fraction(4, 11))
    case2_first_constant = (case2_half_sum + 8 - 1 - Fraction(2, 5)) / (1 - Fraction(2, 5))

    print("\nExact rational case bounds")
    print("--------------------------")
    print(f"q0 = {q0} = {dec(q0, 12)}")
    print(f"Case 1 source deficit bound D = {case1_source_deficit}")
    print(f"Case 1 first affine constant  = {case1_first_constant}")
    print(f"Case 1 final bound            = {case1} = {dec(case1, 12)}")
    print(f"Case 2 half-sum bound H       = {case2_half_sum}")
    print(f"Case 2 first affine constant  = {case2_first_constant}")
    print(f"Case 2 final bound            = {case2} = {dec(case2, 12)}")
    print(f"Final bound                   = {final} = {dec(final, 12)}")

    assert case1 == Fraction(1219, 61)
    assert case2 == Fraction(4898, 245)
    assert final == Fraction(4898, 245)
    assert final < 20
    print("\nAll checks passed.")


if __name__ == "__main__":
    main()
