Polished audited version of the sumset largest-gap paper.

Files:
- sumset_gap_bound_polished.pdf: compiled paper.
- sumset_gap_bound_polished.tex: LaTeX source.
- verify_sumset_gap_certificate.py: exact rational verifier for the finite certificate.
- sumset_gap_certificate.json: rational Farkas certificate.

Verification:
    python3 verify_sumset_gap_certificate.py sumset_gap_certificate.json

Expected output:
    Verified 1073 rational Farkas leaves over 88 roots.
    All internal branch disjunctions are complete.
    No numerical LP solver was used.

SHA-256:
- sumset_gap_certificate.json:
  31ee47a60726ae8d64d75ac3c64d4474ea8c87ab4aa23a50f792e77698626af2
- verify_sumset_gap_certificate.py:
  5c807d4c20638ce50168c2912e784ca8c7b9a2cdcb06bbb5bd3badebecd6a0de
