#!/usr/bin/env python3
"""
Exact verifier for the finite LP certificate in sumset_gap_certificate.json.

It checks the finite part of the proof of
    gap(A)+gap(3A)-2 gap(2A) >= -diam(A)/12
after the mathematical reduction to completed interval unions with at most
five components.

The certificate is rational.  This script uses only Python's Fraction
arithmetic; no numerical LP solver is used.  The verifier reconstructs all
linear systems from the definitions; the certificate supplies only branch
choices and Farkas multipliers.
"""

from __future__ import annotations
import json
import sys
from fractions import Fraction
from collections import defaultdict
from typing import Iterable


def parse_frac(s: str) -> Fraction:
    return Fraction(s)


def add(u, v):
    return [a + b for a, b in zip(u, v)]


def sub(u, v):
    return [a - b for a, b in zip(u, v)]


def scale(c, u):
    return [c * a for a in u]


def zero(n):
    return [Fraction(0) for _ in range(n)]


def pairs(r):
    return [(i, j) for i in range(r) for j in range(i, r)]


def triples(r):
    return [(i, j, k) for i in range(r) for j in range(i, r) for k in range(j, r)]


def is_ideal(S, pairlist):
    S = set(S)
    for i, j in S:
        for k, l in pairlist:
            if k <= i and l <= j and (k, l) not in S:
                return False
    return True


def ideals_pairs(r):
    """All possible lower-side downsets for the selected 2A-gap."""
    pl = pairs(r)
    ans = []
    n = len(pl)
    for mask in range(1, 1 << n):
        S = {pl[k] for k in range(n) if (mask >> k) & 1}
        if len(S) == n:
            continue
        if (0, 0) not in S:
            continue
        if (0, r - 1) in S:
            continue
        if is_ideal(S, pl):
            ans.append(tuple(sorted(S)))
    return ans


class Model:
    def __init__(self, r):
        self.r = r
        # variables: w_0,...,w_{r-1}, h_0,...,h_{r-2}, b, c, p
        self.n = 2 * r + 2
        self.idx_w = list(range(r))
        self.idx_h = list(range(r, 2 * r - 1))
        self.idx_b = 2 * r - 1
        self.idx_c = 2 * r
        self.idx_p = 2 * r + 1

    def unit(self, idx):
        v = zero(self.n)
        v[idx] = Fraction(1)
        return v

    def w(self, i): return self.unit(self.idx_w[i])
    def h(self, i): return self.unit(self.idx_h[i])
    def b(self): return self.unit(self.idx_b)
    def c(self): return self.unit(self.idx_c)
    def p(self): return self.unit(self.idx_p)

    def x(self, i):
        v = zero(self.n)
        for k in range(i):
            v[self.idx_w[k]] += 1
            v[self.idx_h[k]] += 1
        return v

    def y(self, i):
        return add(self.x(i), self.w(i))

    def D(self):
        v = zero(self.n)
        for i in range(self.r):
            v[self.idx_w[i]] += 1
        for i in range(self.r - 1):
            v[self.idx_h[i]] += 1
        return v

    def pair(self, lab):
        i, j = lab
        return add(self.x(i), self.x(j)), add(self.y(i), self.y(j))

    def triple(self, lab):
        i, j, k = lab
        return add(add(self.x(i), self.x(j)), self.x(k)), add(add(self.y(i), self.y(j)), self.y(k))

    def interval(self, kind, lab):
        if kind == 2:
            return self.pair(lab)
        if kind == 3:
            return self.triple(lab)
        raise AssertionError("branch kind must be 2 or 3")


def add_ineq(A, B, coeff, rhs):
    A.append([Fraction(z) for z in coeff])
    B.append(Fraction(rhs))


def build_base(r, L, maxidx):
    """Return M,A,B,E,G for constraints A x <= B, E x = G, x >= 0."""
    M = Model(r)
    A = []
    B = []
    E = []
    G = []

    # Completed-set gaps: h_i >= b.
    for i in range(r - 1):
        add_ineq(A, B, sub(M.b(), M.h(i)), 0)

    # A-gaps bounded by a=2b-c-1.
    for i in range(r - 1):
        add_ineq(A, B, add(sub(M.h(i), scale(2, M.b())), M.c()), -1)

    # One A-gap realizes a.
    E.append(add(sub(M.h(maxidx), scale(2, M.b())), M.c()))
    G.append(Fraction(-1))

    # Derived inequalities b-c >= 2, w_1,w_r >= (b-c)/2.
    add_ineq(A, B, add(scale(-1, M.b()), M.c()), -2)
    add_ineq(A, B, sub(sub(M.b(), M.c()), scale(2, M.w(0))), 0)
    add_ineq(A, B, sub(sub(M.b(), M.c()), scale(2, M.w(r - 1))), 0)

    # The chosen 2A-gap is in the lower half: p+b <= D.
    add_ineq(A, B, add(add(M.p(), M.b()), scale(-1, M.D())), 0)

    # Chosen 2A-gap downset L.
    L = set(L)
    for lab in pairs(r):
        s, e = M.pair(lab)
        if lab in L:
            add_ineq(A, B, sub(e, M.p()), 0)             # e <= p
        else:
            add_ineq(A, B, sub(add(M.p(), M.b()), s), 0) # s >= p+b

    return M, A, B, E, G


def add_path_constraint(M, A, B, step):
    kind, _cut, sigma, tau = step
    s_tau, _ = M.interval(kind, tau)
    _, e_sig = M.interval(kind, sigma)
    t = M.b() if kind == 2 else M.c()
    add_ineq(A, B, sub(sub(s_tau, e_sig), t), 0)


def sparse_to_vec(items, n, name):
    v = [Fraction(0) for _ in range(n)]
    seen = set()
    for idx, val in items:
        idx = int(idx)
        if idx < 0 or idx >= n:
            raise AssertionError(f"{name} index out of range: {idx}")
        if idx in seen:
            raise AssertionError(f"duplicate {name} index: {idx}")
        seen.add(idx)
        v[idx] = parse_frac(val)
    return v


def verify_leaf_cert(M, A, B, E, G, leaf):
    m = len(A)
    q = len(E)
    n = M.n
    lam = sparse_to_vec(leaf["lambda"], m, "lambda")
    mu = sparse_to_vec(leaf["mu"], q, "mu")
    nu = sparse_to_vec(leaf["nu"], n, "nu")

    if any(x < 0 for x in lam):
        raise AssertionError("negative lambda")
    if any(x < 0 for x in nu):
        raise AssertionError("negative lower-bound multiplier")

    if leaf["type"] == "bound":
        target_coeff = M.D()
        target_const = Fraction(-12)
    elif leaf["type"] == "infeas":
        target_coeff = zero(n)
        target_const = Fraction(-1)
    else:
        raise AssertionError("unknown leaf type")

    coeff = zero(n)
    for li, row in zip(lam, A):
        if li:
            coeff = sub(coeff, scale(li, row))
    for mj, row in zip(mu, E):
        if mj:
            coeff = sub(coeff, scale(mj, row))
    coeff = add(coeff, nu)

    const = Fraction(0)
    for li, rhs in zip(lam, B):
        const += li * rhs
    for mj, rhs in zip(mu, G):
        const += mj * rhs

    if coeff != target_coeff or const != target_const:
        raise AssertionError(
            "bad Farkas certificate: got coeff=%r const=%r; target coeff=%r const=%r"
            % (coeff, const, target_coeff, target_const)
        )


def normalize_label_list(xs):
    return tuple(sorted(tuple(y) for y in xs))


def labels_for_kind(r, kind):
    if kind == 2:
        return pairs(r)
    if kind == 3:
        return triples(r)
    raise AssertionError("branch kind must be 2 or 3")


def check_label(label, kind, r):
    label = tuple(label)
    if kind == 2:
        if len(label) != 2:
            raise AssertionError("pair label has wrong length")
        i, j = label
        if not (0 <= i <= j < r):
            raise AssertionError("invalid pair label")
    elif kind == 3:
        if len(label) != 3:
            raise AssertionError("triple label has wrong length")
        i, j, k = label
        if not (0 <= i <= j <= k < r):
            raise AssertionError("invalid triple label")
    else:
        raise AssertionError("branch kind must be 2 or 3")
    return label


def build_trie(leaves, r):
    root = {}
    for leaf in leaves:
        node = root
        for step in leaf["path"]:
            kind = int(step["kind"])
            if kind != 3:
                # The paper's certificate branches only on triple-sum cuts.
                raise AssertionError("certificate contains a non-triple branch")
            cut = normalize_label_list(step["cut"])
            cut = tuple(check_label(x, kind, r) for x in cut)
            sigma = check_label(step["sigma"], kind, r)
            tau = check_label(step["tau"], kind, r)
            key = (kind, cut, sigma, tau)
            node = node.setdefault(("child", key), {})
        if "leaf" in node:
            raise AssertionError("duplicate leaf path")
        node["leaf"] = leaf
    return root


def recurse_verify_node(M, A, B, E, G, node):
    is_leaf = "leaf" in node
    child_keys = [k for k in node if isinstance(k, tuple) and k and k[0] == "child"]

    if is_leaf and child_keys:
        raise AssertionError("node is both leaf and internal")

    if is_leaf:
        verify_leaf_cert(M, A, B, E, G, node["leaf"])
        return 1

    if not child_keys:
        raise AssertionError("empty internal node")

    # All children at a node must be branches of the same valid triple-sum cut.
    first = child_keys[0][1]
    kind, cut, _, _ = first
    if kind != 3:
        raise AssertionError("only triple-sum cuts are allowed")
    for ck in child_keys:
        k2, cut2, _, _ = ck[1]
        if k2 != kind or cut2 != cut:
            raise AssertionError("mixed cuts at one branch node")

    cut = set(cut)
    labels = set(labels_for_kind(M.r, kind))
    if not cut or cut == labels:
        raise AssertionError("invalid empty/full cut")
    if not cut.issubset(labels):
        raise AssertionError("cut labels not valid")

    expected = {(sigma, tau) for sigma in cut for tau in labels if tau not in cut}
    actual = {(ck[1][2], ck[1][3]) for ck in child_keys}
    if actual != expected:
        missing = expected - actual
        extra = actual - expected
        raise AssertionError("branch does not cover disjunction; missing=%r extra=%r" % (missing, extra))

    count = 0
    for ck in child_keys:
        _, (_, _, sigma, tau) = ck
        A2 = [row[:] for row in A]
        B2 = B[:]
        add_path_constraint(M, A2, B2, (kind, tuple(sorted(cut)), sigma, tau))
        count += recurse_verify_node(M, A2, B2, E, G, node[ck])
    return count


def normalize_leaf_path(leaf, r):
    norm_path = []
    for st in leaf["path"]:
        kind = int(st["kind"])
        if kind != 3:
            raise AssertionError("certificate contains a non-triple branch")
        cut = [list(check_label(x, kind, r)) for x in normalize_label_list(st["cut"])]
        sigma = list(check_label(st["sigma"], kind, r))
        tau = list(check_label(st["tau"], kind, r))
        norm_path.append({"kind": kind, "cut": cut, "sigma": sigma, "tau": tau})
    leaf = dict(leaf)
    leaf["path"] = norm_path
    return leaf


def main(path):
    with open(path, "r") as f:
        cert = json.load(f)

    if cert.get("name") != "sumset_gap_1_over_12_certificate":
        raise AssertionError("unexpected certificate name")
    if cert.get("version") != 1:
        raise AssertionError("unexpected certificate version")
    if "leaves" not in cert or not isinstance(cert["leaves"], list):
        raise AssertionError("certificate has no leaf list")

    groups = defaultdict(list)
    for leaf in cert["leaves"]:
        root = leaf["root"]
        r = int(root["r"])
        if not (2 <= r <= 5):
            raise AssertionError("root r out of range")
        L = normalize_label_list(root["L"])
        for lab in L:
            check_label(lab, 2, r)
        maxidx = int(root["maxidx"])
        if not (0 <= maxidx < r - 1):
            raise AssertionError("root maxidx out of range")
        key = (r, tuple(sorted(L)), maxidx)
        groups[key].append(normalize_leaf_path(leaf, r))

    expected_roots = []
    for r in range(2, 6):
        for L in ideals_pairs(r):
            for maxidx in range(r - 1):
                expected_roots.append((r, tuple(sorted(L)), maxidx))
    expected_roots = set(expected_roots)

    if set(groups) != expected_roots:
        raise AssertionError("root set mismatch: missing=%r extra=%r"
                             % (expected_roots - set(groups), set(groups) - expected_roots))

    total = 0
    for r, L, maxidx in sorted(groups):
        M, A, B, E, G = build_base(r, L, maxidx)
        trie = build_trie(groups[(r, L, maxidx)], r)
        total += recurse_verify_node(M, A, B, E, G, trie)

    print("Verified %d rational Farkas leaves over %d roots." % (total, len(expected_roots)))
    print("All internal branch disjunctions are complete.")
    print("No numerical LP solver was used.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: python verify_sumset_gap_certificate.py sumset_gap_certificate.json")
        sys.exit(2)
    main(sys.argv[1])
